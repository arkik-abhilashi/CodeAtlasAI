"""CodeAtlas backend application package."""
